# Waterbutler API action endpoints ----------------------------------------
# https://waterbutler.readthedocs.io/en/latest/api.html#actions


#' Create a folder or subfolder
#'
#' @param id GUID for an OSF project or component
#' @param name Name of the new directory
#' @param fid Optional, provide a Waterbutler folder ID to create the new folder
#'   within the specified existing folder
#'
#' @noRd
.wb_create_folder <- function(id, name, fid = NULL) {
  query <- list(kind = "folder", name = name)
  res <- .wb_request("put", .wb_api_path(id, fid), query = query)
  process_response(res)
}

#' Upload a new file
#'
#' @inheritParams .wb_create_folder
#' @param name Name of the uploaded file
#' @param body Raw file data
#' @param fid: Optional, Waterbutler folder ID to upload the file directly to
#'   the specified existing folder
#'
#' @noRd

.wb_file_upload <- function(id, name, body, fid = NULL, progress = FALSE) {
  query <- list(kind = "file", name = name)
  path <- .wb_api_path(id, fid)
  res <- .wb_request("put", path, query = query, body = body, progress = progress)
  process_response(res)
}

#' Update an existing file
#'
#' @inheritParams .wb_create_folder
#' @inheritParams .wb_file_upload
#' @param fid Existing file's Waterbutler ID
#'
#' @noRd
.wb_file_update <- function(id, fid, body, progress = FALSE) {
  query <- list(kind = "file")
  path <- .wb_api_path(id, fid, type = "file")
  res <- .wb_request("put", path, query = query, body = body, progress = progress)
  process_response(res)
}

#' Download a file
#'
#' @inheritParams .wb_create_folder
#' @param fid Waterbutler ID for the file or folder to download
#' @param path local path where the downloaded file will be saved
#' @param type indicate whether downloading a `"file"` or `"folder"`
#' @param zip Logical, should the downloaded contents be zipped? Only applies to
#'   folders.
#' @inheritParams osf_retrieve_node
#' @return Invisibly returns `TRUE` when the download succeeds
#'
#' @noRd
.wb_download <-
  function(id,
           fid,
           path,
           type,
           zip = FALSE,
           verbose = FALSE,
           progress = FALSE,
           view_only = NULL) {
  type <- match.arg(type, c("file", "folder"))
  query <- list()
  if (zip) query$zip <- ""
  
  query$view_only <- process_view_only(view_only)

  # Get proper file information from metadata if possible
  if (verbose) message("Constructing download URL...")
  
  # Construct the direct Waterbutler URL for downloading
  # This matches the URL structure used by the OSF web interface
  wb_url <- sprintf("https://files.osf.io/v1/resources/%s/providers/osfstorage/%s", 
                   id, fid)
  
  # Add query parameters to URL
  if (length(query) > 0) {
    query_str <- paste(names(query), query, sep = "=", collapse = "&")
    wb_url <- paste0(wb_url, "?", query_str)
  }
  
  if (verbose) message(sprintf("Download URL: %s", wb_url))
  
  # Use httr directly for more control over the download
  if (progress) {
    if (verbose) message("Starting download...")
    res <- httr::GET(wb_url, 
                    httr::write_disk(path, overwrite = TRUE),
                    httr::progress())
  } else {
    res <- httr::GET(wb_url, 
                    httr::write_disk(path, overwrite = TRUE))
  }
  
  # Check if the file contains HTML error content
  is_html_error <- FALSE
  if (file.exists(path)) {
    file_content <- readLines(path, n = 1, warn = FALSE)
    is_html_error <- grepl("<html", file_content, ignore.case = TRUE)
    
    # If we got HTML instead of the file, read the error
    if (is_html_error) {
      file_content <- paste(readLines(path, warn = FALSE), collapse = "\n")
      if (verbose) message("Received HTML error instead of file content:")
      if (verbose) message(file_content)
      file.remove(path)  # Remove the error HTML file
    }
  }
  
  # Handle status and errors
  if (httr::status_code(res) == 200 && !is_html_error) {
    if (verbose) message(sprintf("Successfully downloaded %s to %s", type, path))
    return(invisible(TRUE))
  } else {
    status_code <- httr::status_code(res)
    
    # Handle different error cases
    if (status_code == 404 || is_html_error) {
      error_msg <- paste(
        sprintf("Could not download file (ID: %s) from node %s.", fid, id),
        "When using view-only links, try:",
        "1. Use the view-only link from the specific file, not just the project",
        "2. Ensure you're using the correct file ID (should be the Waterbutler ID)",
        "3. Check that the view-only token is still valid",
        sep = "\n* "
      )
      abort(error_msg)
    } else if (status_code == 403) {
      abort("Access forbidden (HTTP 403). The view-only link doesn't have permission to access this file.")
    } else {
      abort(sprintf("Failed to download file. HTTP status code: %d", status_code))
    }
  }
  }
